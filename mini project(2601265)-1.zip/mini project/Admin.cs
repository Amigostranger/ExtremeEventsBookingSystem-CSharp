﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mini_project
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }
        public static string InputBox(string prompt, string title, string defaultValue)
        {
            InputBoxDialog ib = new InputBoxDialog();
            ib.FormPrompt = prompt;
            ib.FormCaption = title;
            ib.DefaultValue = defaultValue;
            ib.ShowDialog();
            string s = ib.InputResponse;
            ib.Close();
            return s;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            string[] NewEventName = new string[3];
            double[] NewVIPPrice = new double[3];
            for(int i = 0; i < 3; i++)
            {
                NewEventName[i] = Convert.ToString(InputBox("Enter Event", "Event Name", ""));          
            }

            for (int i = 0; i < 3; i++)
            {       
                NewVIPPrice[i] = Convert.ToDouble(InputBox("Enter Price", "Price", ""));
            }
            BookingArray.EventName= NewEventName;
            BookingArray.VIPPrice = NewVIPPrice;

        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }

        private void btnRet_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm f1 = new LoginForm();
            f1.ShowDialog();
            this.Close();
        }
    }
}
