﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mini_project
{
    public partial class Booking : Form
    {
        public Booking()
        {
            InitializeComponent();
        }
        bool blnValidInput = true;

        private void Booking_Load(object sender, EventArgs e)
        {
            int intEventCount;
            for(intEventCount = 0;intEventCount< 3; intEventCount++)
            {
                cboEvent.Items.Add(BookingArray.EventName[intEventCount]);
            }

        }

        private void validateInput()
        {
            if (numRic.Value <= 0)
            {
                blnValidInput = false;
                MessageBox.Show("Invalid number of people");
            }
            if((dateTimePicker1.Value-DateTime.Now).TotalDays <= 6) {
                blnValidInput = false;
                MessageBox.Show("Please book at least Seven days in advance");
                   }
            if(cboEvent.SelectedIndex==-1)
            {blnValidInput = false;MessageBox.Show("Please Select an event"); }
            if(radCpt.Checked==false && radDbn.Checked==false && radJhb.Checked== false)
            {
                blnValidInput=false;
                MessageBox.Show("Please Selected City");
            }
            if (radVip.Checked==false && radSeat.Checked==false && radGen.Checked == false)
            {
                blnValidInput=false;
                MessageBox.Show("Please Select seating");
            }
           // return blnValidInput;
            
        }

        private void makeABookingToolStripMenuItem_Click(object sender, EventArgs e)
        {

            // bool val= validateInput(blnValidInput);
            validateInput();
            if (blnValidInput == true)
            {
                String selected = cboEvent.SelectedItem.ToString();
                int intPriceIndex = 0;
                for (int i = 0; i < cboEvent.Items.Count; i++)
                {
                    if(selected == cboEvent.Items[i].ToString()) { intPriceIndex = i;  }

                }
                Double VipPrice = BookingArray.VIPPrice[intPriceIndex];
                Double GenPrice = VipPrice * 0.8;
                Double SeatPrice = VipPrice * 0.75;
                Double[]priceList=new Double[3];
                Double Cost = 0;
                int numOfPeople = Convert.ToInt32(numRic.Value);
                if (radGen.Checked == true)
                {
                    Cost = GenPrice * numOfPeople;
                }

                if (radVip.Checked == true)
                {
                    Cost = VipPrice * numOfPeople;
                }
                else
                {
                    Cost = SeatPrice * numOfPeople;
                }
                if(chkProgram.Checked== true)
                {
                    Cost += 100;
                }
                if(chkLimo.Checked == true)
                {
                    Cost += 1000;
                }
                lblCost.Text = Cost.ToString("C2");
                lblDate.Text = dateTimePicker1.Value.ToString("mm-dd-yyyy");
                lblNo.Text = numOfPeople.ToString();
                if(radCpt.Checked == true)
                {
                    lblPlace.Text = "Cape Town";

                }
                else if (radDbn.Checked == true)
                {
                    lblPlace.Text = "Durban";
                }
                else
                {
                    lblPlace.Text = "Johannesburg";
                }


                lblName.Text = selected;


            }

        }

        private void clearToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            radGen.Checked = false;
            radVip.Checked = false;
            radSeat.Checked = false;
            chkProgram.Checked = false;
            chkLimo.Checked = false;
            numRic.Value=0;
            cboEvent.SelectedIndex = -1;
            lblCost.Text = "0.00";
            radJhb.Checked = false;
            radCpt.Checked = false;
            radDbn.Checked = false;


        }

        private void returnToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm f1 = new LoginForm();
            f1.ShowDialog();
            this.Close();
        }
    }
}
