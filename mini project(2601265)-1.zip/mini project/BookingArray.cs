﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mini_project
{
    internal class BookingArray
    {
        public static string[] EventName = new string[3];
        public static double[] VIPPrice = new double[3];
    }  
}
