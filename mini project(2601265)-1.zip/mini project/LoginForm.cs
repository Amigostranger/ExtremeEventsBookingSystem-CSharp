﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mini_project
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
    
        }
     

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        

       

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "Admin")
            {
                this.Hide();
                Admin f1 = new Admin();
                f1.ShowDialog();
                this.Close();
            }
            else
            {
                this.Hide();
                Booking f1 = new Booking();
                f1.ShowDialog();
                this.Close();
            }
        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            txtPass.Text = string.Empty;
            //txtPass.Text="";
            comboBox2.Focus();
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

}
